// TODO Implement this library.

class user{
  final String Email;
  final String password;

  user({required this.Email,required this.password});
}