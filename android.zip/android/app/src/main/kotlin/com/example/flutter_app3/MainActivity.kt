package com.example.flutter_app3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
